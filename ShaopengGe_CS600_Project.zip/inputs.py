links = [
    "https://www.nltk.org",
    "https://www.nltk.org/contribute.html",
    "https://www.nltk.org/data.html",
    "https://github.com/nltk/nltk/wiki/FAQ",
    "https://www.nltk.org/api/nltk.html",
]